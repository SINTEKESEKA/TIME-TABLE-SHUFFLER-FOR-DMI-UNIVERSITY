"use client";
import React from "react";

function MainComponent() {
  const [darkMode, setDarkMode] = React.useState(false);
  const [selectedRole, setSelectedRole] = React.useState(null);
  const [selectedRoleForLogin, setSelectedRoleForLogin] = React.useState(null);
  const [showTimetable, setShowTimetable] = React.useState(false);
  const [lecturers, setLecturers] = React.useState([
    "Dr. Smith",
    "Prof. Johnson",
    "Ms. Williams",
  ]);
  const [classes, setClasses] = React.useState([
    "Math 101",
    "Physics 202",
    "Chemistry 301",
  ]);
  const [conflicts, setConflicts] = React.useState([]);
  const [isLoggedIn, setIsLoggedIn] = React.useState(false);
  const [notifications, setNotifications] = React.useState([]);
  const [schedule, setSchedule] = React.useState({});
  const [rooms, setRooms] = React.useState([
    "LH 1",
    "LH 2",
    "LH 3",
    "LH 4",
    "LH 5",
    "CONFERENCE HALL",
    "TH",
    "LAB-1",
    "LAB-2",
  ]);

  const timeSlots = [
    "7:30 AM",
    "8:25 AM",
    "9:20 AM",
    "10:15 AM",
    "11:10 AM",
    "12:05 PM",
    "1:00 PM",
    "1:55 PM",
    "2:50 PM",
    "3:45 PM",
    "4:40 PM",
  ];

  const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];

  const users = {
    "admin@dmi.edu": { password: "admin123", role: "Admin" },
    "lecturer@dmi.edu": { password: "lecturer123", role: "Lecturer" },
    "student@dmi.edu": { password: "student123", role: "Student" },
  };

  const handleLogin = (e) => {
    e.preventDefault();
    const email = e.target.email.value.trim();
    const password = e.target.password.value.trim();

    const validCredentials = Object.entries(users).find(
      ([userEmail, userData]) =>
        userEmail === email &&
        userData.password === password &&
        userData.role === selectedRoleForLogin
    );

    if (validCredentials) {
      setIsLoggedIn(true);
      setSelectedRole(selectedRoleForLogin);
      setNotifications([
        ...notifications,
        {
          type: "success",
          message: `Logged in successfully as ${selectedRoleForLogin}`,
        },
      ]);
    } else {
      setNotifications([
        ...notifications,
        { type: "error", message: "Invalid credentials" },
      ]);
    }
  };

  const shuffleTimetable = () => {
    const newSchedule = {};
    const availableSlots = [];

    days.forEach((_, dayIndex) => {
      timeSlots.forEach((_, timeIndex) => {
        availableSlots.push([dayIndex, timeIndex]);
      });
    });

    for (let i = availableSlots.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [availableSlots[i], availableSlots[j]] = [
        availableSlots[j],
        availableSlots[i],
      ];
    }

    classes.forEach((className) => {
      newSchedule[className] = Array.from({ length: 5 })
        .fill()
        .map(() => Array(timeSlots.length).fill(null));
      const [dayIndex, timeIndex] = availableSlots.pop();
      const randomLecturer =
        lecturers[Math.floor(Math.random() * lecturers.length)];
      const randomRoom = rooms[Math.floor(Math.random() * rooms.length)];
      newSchedule[className][dayIndex][timeIndex] = {
        lecturer: randomLecturer,
        room: randomRoom,
      };
    });

    setSchedule(newSchedule);
    setNotifications([
      ...notifications,
      { type: "success", message: "Timetable shuffled successfully" },
    ]);
  };

  const handleManualSchedule = (day, timeSlot, className, lecturer, room) => {
    const newSchedule = { ...schedule };
    if (!newSchedule[className]) {
      newSchedule[className] = Array.from({ length: 5 })
        .fill()
        .map(() => Array(timeSlots.length).fill(null));
    }
    newSchedule[className][days.indexOf(day)][timeSlots.indexOf(timeSlot)] = {
      lecturer,
      room,
    };
    setSchedule(newSchedule);
    setNotifications([
      ...notifications,
      {
        type: "success",
        message: `Class scheduled: ${className} on ${day} at ${timeSlot}`,
      },
    ]);
  };

  const renderLoginForm = () => (
    <form
      onSubmit={handleLogin}
      className="space-y-4 bg-white dark:bg-black p-8 rounded-lg shadow-md max-w-md w-full"
    >
      <h2 className="text-2xl font-bold mb-6 text-center dark:text-white">
        Login as {selectedRoleForLogin}
      </h2>
      <div>
        <label
          htmlFor="email"
          className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300"
        >
          Email
        </label>
        <input
          type="email"
          id="email"
          name="email"
          required
          className="w-full p-3 border rounded-md focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
        />
      </div>
      <div>
        <label
          htmlFor="password"
          className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300"
        >
          Password
        </label>
        <input
          type="password"
          id="password"
          name="password"
          required
          className="w-full p-3 border rounded-md focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
        />
      </div>
      <button
        type="submit"
        className="w-full bg-blue-500 text-white p-3 rounded-md hover:bg-blue-600 transition duration-300"
      >
        Login
      </button>
      <button
        type="button"
        onClick={() => setSelectedRoleForLogin(null)}
        className="w-full mt-2 bg-gray-300 text-gray-800 p-3 rounded-md hover:bg-gray-400 transition duration-300"
      >
        Back
      </button>
    </form>
  );

  const renderManualScheduleForm = () => (
    <div className="mt-6 bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
      <h3 className="text-xl font-semibold mb-4 dark:text-white">
        Manual Scheduling
      </h3>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleManualSchedule(
            e.target.day.value,
            e.target.timeSlot.value,
            e.target.className.value,
            e.target.lecturer.value,
            e.target.room.value
          );
        }}
        className="space-y-4"
      >
        <select name="day" required className="w-full p-2 border rounded">
          {days.map((day) => (
            <option key={day} value={day}>
              {day}
            </option>
          ))}
        </select>
        <select name="timeSlot" required className="w-full p-2 border rounded">
          {timeSlots.map((slot) => (
            <option key={slot} value={slot}>
              {slot}
            </option>
          ))}
        </select>
        <select name="className" required className="w-full p-2 border rounded">
          {classes.map((className) => (
            <option key={className} value={className}>
              {className}
            </option>
          ))}
        </select>
        <select name="lecturer" required className="w-full p-2 border rounded">
          {lecturers.map((lecturer) => (
            <option key={lecturer} value={lecturer}>
              {lecturer}
            </option>
          ))}
        </select>
        <select name="room" required className="w-full p-2 border rounded">
          {rooms.map((room) => (
            <option key={room} value={room}>
              {room}
            </option>
          ))}
        </select>
        <button
          type="submit"
          className="w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-600 transition duration-300"
        >
          Schedule Class
        </button>
      </form>
    </div>
  );

  const renderTimetable = () => {
    return (
      <div className="mt-6 bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md w-full overflow-x-auto">
        <h2 className="text-2xl font-semibold mb-6 dark:text-white">
          Timetable
        </h2>
        <table className="w-full border-collapse">
          <thead>
            <tr>
              <th className="border p-3 dark:border-gray-600 dark:text-white">
                Time
              </th>
              {days.map((day) => (
                <th
                  key={day}
                  className="border p-3 dark:border-gray-600 dark:text-white"
                >
                  {day}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {timeSlots.map((time, timeIndex) => (
              <tr key={time}>
                <td className="border p-3 dark:border-gray-600 dark:text-white">
                  {time}
                </td>
                {days.map((day, dayIndex) => (
                  <td
                    key={`${day}-${time}`}
                    className="border p-3 dark:border-gray-600"
                  >
                    {Object.entries(schedule).map(
                      ([className, classSchedule]) => {
                        const scheduleItem = classSchedule[dayIndex][timeIndex];
                        if (scheduleItem) {
                          return (
                            <div
                              key={className}
                              className="bg-blue-100 dark:bg-gray-700 p-2 rounded mb-1"
                            >
                              <p className="font-semibold dark:text-white">
                                {className}
                              </p>
                              <p className="text-sm text-gray-600 dark:text-gray-300">
                                Lecturer: {scheduleItem.lecturer}
                              </p>
                              <p className="text-sm text-gray-600 dark:text-gray-300">
                                Room: {scheduleItem.room}
                              </p>
                            </div>
                          );
                        }
                        return null;
                      }
                    )}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  const roleSpecificContent = (role) => {
    switch (role) {
      case "Admin":
        return (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <div className="bg-blue-100 dark:bg-blue-900 p-4 rounded-lg">
                <h3 className="text-lg font-semibold mb-2 dark:text-white">
                  Total Lecturers
                </h3>
                <p className="text-3xl font-bold dark:text-white">
                  {lecturers.length}
                </p>
              </div>
              <div className="bg-green-100 dark:bg-green-900 p-4 rounded-lg">
                <h3 className="text-lg font-semibold mb-2 dark:text-white">
                  Total Classes
                </h3>
                <p className="text-3xl font-bold dark:text-white">
                  {classes.length}
                </p>
              </div>
              <div className="bg-yellow-100 dark:bg-yellow-900 p-4 rounded-lg">
                <h3 className="text-lg font-semibold mb-2 dark:text-white">
                  Total Rooms
                </h3>
                <p className="text-3xl font-bold dark:text-white">
                  {rooms.length}
                </p>
              </div>
            </div>
            <div className="flex space-x-4 mb-6">
              <button
                onClick={shuffleTimetable}
                className="bg-purple-500 text-white px-6 py-3 rounded-lg shadow hover:bg-purple-600 transition duration-300"
              >
                Shuffle Timetable
              </button>
            </div>
            {renderManualScheduleForm()}
            {renderTimetable()}
          </>
        );
      case "Lecturer":
      case "Student":
        return (
          <>
            <button
              className={`bg-${
                role === "Lecturer" ? "blue" : "yellow"
              }-500 text-white px-6 py-3 rounded-lg shadow hover:bg-${
                role === "Lecturer" ? "blue" : "yellow"
              }-600 transition duration-300`}
              type="button"
              onClick={() => setShowTimetable(!showTimetable)}
            >
              {showTimetable ? "Hide" : "View"} Timetable
            </button>
            {showTimetable && renderTimetable()}
          </>
        );
      default:
        return null;
    }
  };

  return (
    <div
      className={`flex flex-col min-h-screen transition-colors duration-300 ${
        darkMode ? "bg-gray-900 text-white" : "bg-gray-100 text-black"
      }`}
    >
      <header
        className={`transition-colors duration-300 ${
          darkMode ? "bg-gray-800" : "bg-white"
        } shadow-md`}
      >
        <div className="container mx-auto px-4 py-6 flex justify-between items-center">
          <h1 className="text-3xl font-bold">
            DMI University Timetable Shuffler
          </h1>
          <button
            onClick={() => setDarkMode(!darkMode)}
            className={`p-2 rounded-full ${
              darkMode ? "bg-yellow-400 text-black" : "bg-gray-800 text-white"
            } transition-colors duration-300`}
          >
            {darkMode ? (
              <i className="fas fa-sun"></i>
            ) : (
              <i className="fas fa-moon"></i>
            )}
          </button>
        </div>
      </header>
      <main className="flex-grow container mx-auto px-4 py-8">
        {!isLoggedIn ? (
          <div className="flex justify-center items-center h-full">
            {selectedRoleForLogin ? (
              renderLoginForm()
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {["Admin", "Lecturer", "Student"].map((role) => (
                  <button
                    key={role}
                    className={`bg-${
                      role === "Admin"
                        ? "blue"
                        : role === "Lecturer"
                        ? "green"
                        : "yellow"
                    }-500 text-white p-6 rounded-lg shadow-md hover:bg-${
                      role === "Admin"
                        ? "blue"
                        : role === "Lecturer"
                        ? "green"
                        : "yellow"
                    }-600 transition duration-300 flex flex-col items-center`}
                    onClick={() => setSelectedRoleForLogin(role)}
                  >
                    <i
                      className={`fas fa-${
                        role === "Admin"
                          ? "user-cog"
                          : role === "Lecturer"
                          ? "chalkboard-teacher"
                          : "user-graduate"
                      } text-4xl mb-2`}
                    ></i>
                    <span className="text-xl">{role}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-6">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
              <h2 className="text-2xl font-semibold mb-6 dark:text-white">
                {selectedRole} Dashboard
              </h2>
              {roleSpecificContent(selectedRole)}
              <button
                onClick={() => {
                  setIsLoggedIn(false);
                  setSelectedRole(null);
                  setSelectedRoleForLogin(null);
                  setShowTimetable(false);
                }}
                className="mt-4 px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600 transition duration-300"
              >
                <i className="fas fa-sign-out-alt mr-2"></i> Logout
              </button>
            </div>
          </div>
        )}
      </main>
      <div className="fixed bottom-4 right-4 flex flex-col space-y-2">
        {notifications.map((notification, index) => (
          <div
            key={index}
            className={`p-4 rounded-lg shadow-md ${
              notification.type === "success"
                ? "bg-green-500"
                : notification.type === "error"
                ? "bg-red-500"
                : notification.type === "warning"
                ? "bg-yellow-500"
                : "bg-blue-500"
            } text-white`}
          >
            {notification.message}
          </div>
        ))}
      </div>
    </div>
  );
}

export default MainComponent;